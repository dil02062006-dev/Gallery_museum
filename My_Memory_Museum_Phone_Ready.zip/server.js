const express=require('express'),http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto'),multer=require('multer');
const {Server}=require('socket.io');
const app=express(),srv=http.createServer(app),io=new Server(srv);
const PORT=process.env.PORT||3000,KEY=process.env.OWNER_KEY||'changeme',SLOTS=12;
const UP=path.join(__dirname,'uploads'),DBF=path.join(__dirname,'data','gallery.json');
fs.mkdirSync(UP,{recursive:true});fs.mkdirSync(path.dirname(DBF),{recursive:true});
let db=fs.existsSync(DBF)?JSON.parse(fs.readFileSync(DBF,'utf8')):{photos:[],theme:{wall:'#e8e2d6',floor:'marble',light:1}};
const save=()=>{fs.writeFileSync(DBF,JSON.stringify(db,null,1));io.emit('gallery',db)};
const ext={'image/jpeg':'.jpg','image/png':'.png','image/webp':'.webp'};
const upload=multer({storage:multer.diskStorage({destination:UP,filename:(q,f,cb)=>cb(null,crypto.randomBytes(8).toString('hex')+ext[f.mimetype])}),
  limits:{fileSize:12e6},fileFilter:(q,f,cb)=>cb(ext[f.mimetype]?null:new Error('Only JPG, PNG or WEBP allowed'),!!ext[f.mimetype])});
const owner=(q,r,n)=>q.get('x-owner-key')===KEY?n():r.status(401).json({error:'Owner key required'});
const rm=f=>fs.unlink(path.join(UP,path.basename(f)),()=>{});
const free=()=>{for(let i=0;i<SLOTS;i++)if(!db.photos.some(p=>p.slot===i))return i;return -1};
app.use(express.json());
app.use('/uploads',express.static(UP,{maxAge:'7d'}));
app.use(express.static(path.join(__dirname,'public')));
app.get('/api/gallery',(q,r)=>r.json(db));
app.get('/api/auth',owner,(q,r)=>r.json({ok:1}));
app.post('/api/photos',owner,upload.single('photo'),(q,r)=>{
  if(!q.file)return r.status(400).json({error:'No file'});
  const s=free();if(s<0){rm(q.file.filename);return r.status(400).json({error:'Gallery full (12 frames) – delete one first'})}
  db.photos.push({id:crypto.randomUUID(),file:q.file.filename,title:String(q.body.title||'Untitled').slice(0,80),desc:String(q.body.desc||'').slice(0,500),frame:'gold',slot:s});
  save();r.json({ok:1})});
app.patch('/api/photos/:id',owner,(q,r)=>{
  const p=db.photos.find(x=>x.id===q.params.id);if(!p)return r.sendStatus(404);const b=q.body;
  if('title' in b)p.title=String(b.title).slice(0,80);
  if('desc' in b)p.desc=String(b.desc).slice(0,500);
  if(['gold','black','wood','white'].includes(b.frame))p.frame=b.frame;
  if(Number.isInteger(b.slot)&&b.slot>=0&&b.slot<SLOTS&&b.slot!==p.slot){const o=db.photos.find(x=>x.slot===b.slot);if(o)o.slot=p.slot;p.slot=b.slot}
  save();r.json({ok:1})});
app.put('/api/photos/:id/file',owner,upload.single('photo'),(q,r)=>{
  const p=db.photos.find(x=>x.id===q.params.id);if(!p||!q.file)return r.sendStatus(400);
  rm(p.file);p.file=q.file.filename;save();r.json({ok:1})});
app.delete('/api/photos/:id',owner,(q,r)=>{
  const i=db.photos.findIndex(x=>x.id===q.params.id);if(i<0)return r.sendStatus(404);
  rm(db.photos[i].file);db.photos.splice(i,1);save();r.json({ok:1})});
app.put('/api/theme',owner,(q,r)=>{
  const b=q.body,t=db.theme;
  if(/^#[0-9a-f]{6}$/i.test(b.wall))t.wall=b.wall;
  if(['marble','wood','dark'].includes(b.floor))t.floor=b.floor;
  if(b.light>=.3&&b.light<=2)t.light=+b.light;
  save();r.json({ok:1})});
app.use((e,q,r,n)=>r.status(400).json({error:e.message}));

// ---- realtime rooms ----
const rooms={};
function leave(s){const c=s.data.room;if(!c||!rooms[c])return;s.leave(c);delete rooms[c][s.id];io.to(c).emit('left',s.id);if(!Object.keys(rooms[c]).length)delete rooms[c];s.data.room=null}
function enter(s,c,name,cb){leave(s);name=String(name||'Guest').slice(0,16);s.join(c);s.data.room=c;
  const me=rooms[c][s.id]={id:s.id,name,x:-17,z:0,ry:0,mv:0};
  cb({code:c,players:Object.values(rooms[c]).filter(p=>p.id!==s.id)});s.to(c).emit('joined',me)}
io.on('connection',s=>{s.data={};
  s.on('create',(name,cb)=>{let c;do{c=crypto.randomBytes(3).toString('hex').slice(0,4).toUpperCase()}while(rooms[c]);rooms[c]={};enter(s,c,name,cb)});
  s.on('join',(c,name,cb)=>{c=String(c||'').toUpperCase();if(!rooms[c])return cb({error:'Room not found'});enter(s,c,name,cb)});
  s.on('move',m=>{const r=rooms[s.data.room],p=r&&r[s.id];if(!p)return;p.x=+m.x||0;p.z=+m.z||0;p.ry=+m.ry||0;p.mv=+m.mv||0;s.to(s.data.room).volatile.emit('move',p)});
  s.on('disconnect',()=>leave(s));
});
srv.listen(PORT,'0.0.0.0',()=>console.log(`Museum running on http://localhost:${PORT}  (owner key: ${KEY==='changeme'?'changeme – set OWNER_KEY!':'set'})`));

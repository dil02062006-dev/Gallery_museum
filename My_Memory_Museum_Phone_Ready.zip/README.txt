MY MEMORY MUSEUM — PHONE-READY PROJECT

This project has been arranged for a Node.js web host. It is a server-backed 3D gallery game with rooms/multiplayer and gallery management. Do not open public/index.html directly as a file.

FILES
- server.js: Express + Socket.IO server
- public/index.html: browser game
- data/gallery.json: initial gallery records
- uploads/seed1.jpg ... seed7.jpg: initial gallery images

RUN ON A COMPUTER
1. Install Node.js LTS.
2. Open this folder in a terminal.
3. Run: npm install
4. Run: npm start
5. Open http://localhost:3000 in a browser.

HOST ONLINE (so your iPhone can play)
This needs a Node.js host; GitHub Pages alone cannot run this server. Upload/push this folder to a Git repository, then create a Node web service from that repository on a hosting provider that supports Node.js. Use the start command `npm start` and set environment variable OWNER_KEY to a private password of your choice (do not use `changeme`). Then open the service's HTTPS URL in Safari.

IMPORTANT
- This original project stores uploaded photos and gallery edits on the server filesystem. Some free hosts use temporary storage, so uploads/edits may reset after a restart/redeploy unless persistent storage is enabled.
- The game uses CDN-loaded Three.js and requires internet access.
- Mobile touch controls are included in the game.
- Owner login uses the OWNER_KEY environment variable; set it securely in your host dashboard.
